Please unzip the file
This script generates a folder with the skeleton